using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyTourApp
{
    public partial class FormDatTour : Form
    {
        public FormDatTour()
        {
            InitializeComponent();
            LoadBookings();
            LoadCustomers();
            LoadTours();
        }

        private void LoadBookings()
        {
            var dt = DataAccess.GetDataTable("SELECT d.DatID, k.TaiKhoan, t.TenTour, d.NgayDat, d.SoNguoi FROM DatTour d JOIN KhachHang k ON d.KhID=k.KhID JOIN Tours t ON d.TourID=t.TourID");
            dataGridViewBookings.DataSource = dt;
            dataGridViewBookings.Columns["DatID"].Visible = false;
        }

        private void LoadCustomers()
        {
            var dt = DataAccess.GetDataTable("SELECT KhID, TaiKhoan FROM KhachHang");
            comboKhach.DataSource = dt;
            comboKhach.DisplayMember = "TaiKhoan";
            comboKhach.ValueMember = "KhID";
        }

        private void LoadTours()
        {
            var dt = DataAccess.GetDataTable("SELECT TourID, TenTour FROM Tours");
            comboTour.DataSource = dt;
            comboTour.DisplayMember = "TenTour";
            comboTour.ValueMember = "TourID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int khid = Convert.ToInt32(comboKhach.SelectedValue);
            int tourid = Convert.ToInt32(comboTour.SelectedValue);
            int songuoi = (int)numericSoNguoi.Value;
            DataAccess.Execute("INSERT INTO DatTour(KhID,TourID,SoNguoi) VALUES(@kh,@tour,@so)",
                new SqlParameter[] {
                    new SqlParameter("@kh", khid),
                    new SqlParameter("@tour", tourid),
                    new SqlParameter("@so", songuoi)
                });
            LoadBookings();
        }
    }
}
