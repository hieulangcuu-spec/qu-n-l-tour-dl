using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyTourApp
{
    public partial class FormKhachHang : Form
    {
        public FormKhachHang()
        {
            InitializeComponent();
            LoadCustomers();
        }

        private void LoadCustomers()
        {
            var dt = DataAccess.GetDataTable("SELECT KhID, TaiKhoan, HoDem, Ten, GioiTinh, NgaySinh, DiaChi FROM KhachHang");
            dataGridViewCustomers.DataSource = dt;
            dataGridViewCustomers.Columns["KhID"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DataAccess.Execute("INSERT INTO KhachHang(TaiKhoan,HoDem,Ten,GioiTinh,NgaySinh,DiaChi) VALUES(@tk,@hd,@ten,@gt,@ns,@dc)",
                new SqlParameter[] {
                    new SqlParameter("@tk", txtTaiKhoan.Text.Trim()),
                    new SqlParameter("@hd", txtHoDem.Text.Trim()),
                    new SqlParameter("@ten", txtTen.Text.Trim()),
                    new SqlParameter("@gt", comboGT.Text),
                    new SqlParameter("@ns", (object)dateNgaySinh.Value.Date),
                    new SqlParameter("@dc", txtDiaChi.Text.Trim())
                });
            LoadCustomers();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridViewCustomers.CurrentRow.Cells["KhID"].Value);
            DataAccess.Execute("UPDATE KhachHang SET TaiKhoan=@tk,HoDem=@hd,Ten=@ten,GioiTinh=@gt,NgaySinh=@ns,DiaChi=@dc WHERE KhID=@id",
                new SqlParameter[] {
                    new SqlParameter("@tk", txtTaiKhoan.Text.Trim()),
                    new SqlParameter("@hd", txtHoDem.Text.Trim()),
                    new SqlParameter("@ten", txtTen.Text.Trim()),
                    new SqlParameter("@gt", comboGT.Text),
                    new SqlParameter("@ns", (object)dateNgaySinh.Value.Date),
                    new SqlParameter("@dc", txtDiaChi.Text.Trim()),
                    new SqlParameter("@id", id)
                });
            LoadCustomers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridViewCustomers.CurrentRow.Cells["KhID"].Value);
            DataAccess.Execute("DELETE FROM KhachHang WHERE KhID=@id", new SqlParameter[] { new SqlParameter("@id", id) });
            LoadCustomers();
        }

        private void dataGridViewCustomers_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.CurrentRow == null) return;
            txtTaiKhoan.Text = dataGridViewCustomers.CurrentRow.Cells["TaiKhoan"].Value?.ToString();
            txtHoDem.Text = dataGridViewCustomers.CurrentRow.Cells["HoDem"].Value?.ToString();
            txtTen.Text = dataGridViewCustomers.CurrentRow.Cells["Ten"].Value?.ToString();
            comboGT.Text = dataGridViewCustomers.CurrentRow.Cells["GioiTinh"].Value?.ToString();
            if (dataGridViewCustomers.CurrentRow.Cells["NgaySinh"].Value != DBNull.Value)
                dateNgaySinh.Value = Convert.ToDateTime(dataGridViewCustomers.CurrentRow.Cells["NgaySinh"].Value);
            txtDiaChi.Text = dataGridViewCustomers.CurrentRow.Cells["DiaChi"].Value?.ToString();
        }
    }
}
