using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyTourApp
{
    public static class DataAccess
    {
        private static string _conn = System.Configuration.ConfigurationManager.ConnectionStrings["QuanLyTourDB"].ConnectionString;

        public static DataTable GetDataTable(string sql, params SqlParameter[] pars)
        {
            using (SqlConnection cn = new SqlConnection(_conn))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static int Execute(string sql, params SqlParameter[] pars)
        {
            using (SqlConnection cn = new SqlConnection(_conn))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string sql, params SqlParameter[] pars)
        {
            using (SqlConnection cn = new SqlConnection(_conn))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                cn.Open();
                return cmd.ExecuteScalar();
            }
        }
    }
}
