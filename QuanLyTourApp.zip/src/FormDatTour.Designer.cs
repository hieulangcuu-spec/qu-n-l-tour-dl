namespace QuanLyTourApp
{
    partial class FormDatTour
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridViewBookings = new System.Windows.Forms.DataGridView();
            this.comboKhach = new System.Windows.Forms.ComboBox();
            this.comboTour = new System.Windows.Forms.ComboBox();
            this.numericSoNguoi = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSoNguoi)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBookings
            // 
            this.dataGridViewBookings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
                | System.Windows.Forms.AnchorStyles.Left) 
                | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBookings.Location = new System.Drawing.Point(12, 100);
            this.dataGridViewBookings.Name = "dataGridViewBookings";
            this.dataGridViewBookings.RowTemplate.Height = 24;
            this.dataGridViewBookings.Size = new System.Drawing.Size(760, 350);
            this.dataGridViewBookings.TabIndex = 0;
            // 
            // comboKhach
            // 
            this.comboKhach.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboKhach.Location = new System.Drawing.Point(12, 12);
            this.comboKhach.Name = "comboKhach";
            this.comboKhach.Size = new System.Drawing.Size(200, 24);
            this.comboKhach.TabIndex = 1;
            // 
            // comboTour
            // 
            this.comboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboTour.Location = new System.Drawing.Point(230, 12);
            this.comboTour.Name = "comboTour";
            this.comboTour.Size = new System.Drawing.Size(200, 24);
            this.comboTour.TabIndex = 2;
            // 
            // numericSoNguoi
            // 
            this.numericSoNguoi.Location = new System.Drawing.Point(450, 12);
            this.numericSoNguoi.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericSoNguoi.Name = "numericSoNguoi";
            this.numericSoNguoi.Size = new System.Drawing.Size(80, 22);
            this.numericSoNguoi.TabIndex = 3;
            this.numericSoNguoi.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(550, 10);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(80, 28);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Đặt";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // FormDatTour
            // 
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.numericSoNguoi);
            this.Controls.Add(this.comboTour);
            this.Controls.Add(this.comboKhach);
            this.Controls.Add(this.dataGridViewBookings);
            this.Name = "FormDatTour";
            this.Text = "Đặt Tour";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericSoNguoi)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.DataGridView dataGridViewBookings;
        private System.Windows.Forms.ComboBox comboKhach;
        private System.Windows.Forms.ComboBox comboTour;
        private System.Windows.Forms.NumericUpDown numericSoNguoi;
        private System.Windows.Forms.Button btnAdd;
    }
}
