using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyTourApp
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            LoadTours();
        }

        private void LoadTours(string filter = null)
        {
            string sql = "SELECT TourID, MaTour, TenTour, DiaDiem, Gia FROM Tours";
            SqlParameter[] pars = null;
            if (!string.IsNullOrEmpty(filter))
            {
                sql += " WHERE TenTour LIKE @f OR MaTour LIKE @f";
                pars = new SqlParameter[] { new SqlParameter("@f", "%" + filter + "%") };
            }
            var dt = DataAccess.GetDataTable(sql, pars);
            dataGridViewTours.DataSource = dt;
            dataGridViewTours.Columns["TourID"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string ma = txtMa.Text.Trim();
            string ten = txtTen.Text.Trim();
            string dd = txtDiaDiem.Text.Trim();
            decimal gia = numericGia.Value;
            try
            {
                DataAccess.Execute("INSERT INTO Tours(MaTour,TenTour,DiaDiem,Gia) VALUES(@ma,@ten,@dd,@gia)",
                    new SqlParameter[] {
                        new SqlParameter("@ma", ma),
                        new SqlParameter("@ten", ten),
                        new SqlParameter("@dd", dd),
                        new SqlParameter("@gia", gia)
                    });
                LoadTours();
                MessageBox.Show("Thêm tour thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridViewTours.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridViewTours.CurrentRow.Cells["TourID"].Value);
            string ma = txtMa.Text.Trim();
            string ten = txtTen.Text.Trim();
            string dd = txtDiaDiem.Text.Trim();
            decimal gia = numericGia.Value;
            DataAccess.Execute("UPDATE Tours SET MaTour=@ma,TenTour=@ten,DiaDiem=@dd,Gia=@gia WHERE TourID=@id",
                new SqlParameter[] {
                    new SqlParameter("@ma", ma),
                    new SqlParameter("@ten", ten),
                    new SqlParameter("@dd", dd),
                    new SqlParameter("@gia", gia),
                    new SqlParameter("@id", id)
                });
            LoadTours();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewTours.CurrentRow == null) return;
            int id = Convert.ToInt32(dataGridViewTours.CurrentRow.Cells["TourID"].Value);
            if (MessageBox.Show("Bạn có muốn xóa tour này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DataAccess.Execute("DELETE FROM Tours WHERE TourID=@id", new SqlParameter[] { new SqlParameter("@id", id) });
                LoadTours();
            }
        }

        private void dataGridViewTours_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewTours.CurrentRow == null) return;
            txtMa.Text = dataGridViewTours.CurrentRow.Cells["MaTour"].Value?.ToString();
            txtTen.Text = dataGridViewTours.CurrentRow.Cells["TenTour"].Value?.ToString();
            txtDiaDiem.Text = dataGridViewTours.CurrentRow.Cells["DiaDiem"].Value?.ToString();
            if (dataGridViewTours.CurrentRow.Cells["Gia"].Value != DBNull.Value)
                numericGia.Value = Convert.ToDecimal(dataGridViewTours.CurrentRow.Cells["Gia"].Value);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadTours(txtSearch.Text.Trim());
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            LoadTours();
        }

        private void btnManageCustomers_Click(object sender, EventArgs e)
        {
            var f = new FormKhachHang();
            f.ShowDialog();
        }

        private void btnManageBookings_Click(object sender, EventArgs e)
        {
            var f = new FormDatTour();
            f.ShowDialog();
        }
    }
}
