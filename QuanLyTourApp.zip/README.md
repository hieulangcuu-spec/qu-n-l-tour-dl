# QuanLyTourApp - C# WinForms (Source bundle)
This bundle contains C# source files and SQL script to create the database for a simple Tour Management WinForms app.
It is ready to be pasted into a Visual Studio WinForms project (create a WinForms project first, then replace/add files).

**Included**
- sql/CreateDatabase_QuanLyTourDB.sql
- src/DataAccess.cs
- src/Program.cs
- src/FormMain.cs
- src/FormMain.Designer.cs
- src/FormKhachHang.cs
- src/FormKhachHang.Designer.cs
- src/FormDatTour.cs
- src/FormDatTour.Designer.cs
- App.config

**How to use**
1. Open Visual Studio (2019/2022). Create a new project: "Windows Forms App (.NET Framework)" targeting .NET Framework 4.7.2 (or similar).
2. Add the files from `src/` to the project (Right click project > Add > Existing Item).
3. Run the SQL script in SQL Server (SSMS) or use Visual Studio Server Explorer to create the database.
4. Update the connection string in App.config to match your server (LocalDB or SQL Server).
5. Build & Run.

If you want, you can also create a new folder in your project, paste these files, and open FormMain in Designer to see the UI.
